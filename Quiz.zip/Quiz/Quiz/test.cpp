// test.cpp
// Test the output the quicksort and max heap

#include <iostream>
#include <vector>
#include "QuickSort.hpp"
#include "MaxHeap.hpp"

int main()
{
	std::vector<int> vec{ 5,2,7,1,9,8 };
	QuickSort(vec);
	for (int i = 0; i < vec.size(); ++i)
	{
		std::cout << vec[i] << ", ";		// 1,2,5,7,8,9
	}
	std::cout << std::endl;

	MaxHeap<int> max_heap;
	max_heap.Add(5);
	max_heap.Add(2);
	max_heap.Add(11);
	max_heap.Add(42);
	max_heap.Add(9);
	
	max_heap.Print();		// 42, 11, 5, 2, 9
	max_heap.Remove(2);
	max_heap.Print();		// 42, 11, 9, 2

	return 0;
}