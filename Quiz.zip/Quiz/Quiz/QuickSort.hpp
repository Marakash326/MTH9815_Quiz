// QuickSort.hpp
// The algorithm to quick sort an array of integers

#ifndef QUICKSORT_HPP
#define QUICKSORT_HPP

#include <iostream>
#include <vector>

// quick sort the array from index left to index right (inclusive) in-place
void quicksort_helper(std::vector<int>& arr, int left, int right)
{
	if (left >= right)
		return;
	// i is the correct position of the pivot
	int i = left, j = right;
	// picks the leftmost element as the pivot
	int pivot = arr[left];

    while (i != j)
    {
        // from right to left, the first element smaller than pivot
        while (arr[j] >= pivot && j > i)
            --j;
        // if j == i, then all other elements >= the pivot, ends
        if (j > i)
        {
            arr[i] = arr[j];  // move the smaller element left
            ++i;
        }
        // from left to right, the first element larger than pivot
        while (arr[i] <= pivot && j > i)
            ++i;
        if (j > i)
        {
            arr[j] = arr[i];  // move the larger element right
            --j;
        }
    }
    arr[i] = pivot;
    // sort the two subarrays recursively
    quicksort_helper(arr, left, i - 1);
    quicksort_helper(arr, i + 1, right);
}

// Quick sort the entire array in-place
void QuickSort(std::vector<int>& arr)
{
    int n = arr.size();
    quicksort_helper(arr, 0, n - 1);
}

#endif