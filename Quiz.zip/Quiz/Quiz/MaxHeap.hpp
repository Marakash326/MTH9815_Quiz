// MaxHeap.hpp
// Declaration and implementation of the max heap

#include <iostream>
#include <vector>

template <typename T>
class MaxHeap
{
private:
	std::vector<T> arr;		// use a vector to store the values
	int parent(int i)		// the parent index of node i
	{
		return (i - 1) / 2;
	}
	int left_child(int i)		// the left child of node i
	{
		return 2 * i + 1;
	}
	int right_child(int i)		// the right child of node i
	{
		return 2 * i + 2;
	}

	void Heapify(int i)			// turn the array into a heap at index i
	{
		int l = left_child(i), r = right_child(i);
		int largest;
		if (l <= arr.size() && arr[l] > arr[i])
			largest = l;
		else largest = i;

		if (r <= arr.size() && arr[r] > arr[largest])
			largest = r;

		if (largest != i) 
		{
			int temp = arr[i];
			arr[i] = arr[largest];
			arr[largest] = temp;
			Heapify(largest);
		}
		return;
	}

public:
	MaxHeap(): arr(std::vector<T>()) {}

	void Add(T val)		// add a new element into the heap
	{
		arr.push_back(val);
		int cur = arr.size() - 1;
		int pos = parent(cur);
		while (arr[cur] > arr[pos]) 
		{
			int temp = arr[cur];
			arr[cur] = arr[pos];
			arr[pos] = temp;
			cur = pos;
			pos = parent(cur);
		}
		return;
	}

	int Remove(int index)		// remove an element with the specified index
	{
		if (index >= arr.size())
			return -1;
		int ans = arr[index];
		arr[index] = arr[arr.size() - 1];
		arr.pop_back();
		Heapify(index);
		return ans;
	}

	void Print()		// print all elements in the heap
	{
		for (int i = 0; i < arr.size(); ++i)
			std::cout << arr[i] << ", ";
		std::cout << std::endl;
	}
};