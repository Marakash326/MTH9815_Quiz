// main.cpp
// Test results of all 3 exercises

#include "Test_Exercise1.hpp"
#include "Test_Exercise2.hpp"
#include "Test_Exercise3.hpp"

int main()
{
	//Test_Exercise1();
	//Test_Exercise2();
	Test_Exercise3();
	return 0;
}